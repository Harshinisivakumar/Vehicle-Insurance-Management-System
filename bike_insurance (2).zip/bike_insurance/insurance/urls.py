
from django.urls import path
from . import views  
from .views import user_login, signup ,complaint_view , signup_view
from .views import reminder_list, add_reminder, delete_reminder
from .views import customer_form_view, customer_success 
from .views import claim_request_view
from .views import claim_request_form
from .views import insurance_list, add_insurance, edit_insurance, delete_insurance
from .views import report_view

urlpatterns = [
    path('login/', user_login, name='login'),
    path('signup/', signup_view, name='signup'), 
    path('login/', views.login_view, name='login'),
    path('', views.home_view, name='home'),
   
    path('customer-form/', views.customer_form_view, name='customer_form'),
    path('success/<int:customer_id>/', views.customer_success_page, name='customer_success'),  
    path('edit-customer/<int:customer_id>/', views.edit_customer, name='edit_customer'),
    path('customer-form/', customer_form_view, name='customer_form'),
    path('success/<int:customer_id>/', customer_success, name='customer_success_page'), 
    path('dealers/', views.dealer_list, name='dealer_list'),
    
    # Policy Management URLs
    path('policy-form/', views.policy_form_view, name='policy_form'),  # New policy
    path('policy-form/<int:policy_id>/', views.policy_form_view, name='edit_policy'),  # Edit policy
    path('policy-list/', views.policy_list, name='policy_list'),  # Policy list page
    path('renew-policy/<int:policy_id>/', views.renew_policy, name='renew_policy'),  # Renew policy
    path('download-policy/<int:policy_id>/', views.download_policy_document, name='download_policy_document'),  # Download policy

    #complaint
    path('complaint/', complaint_view, name='complaint'),
    
    #insurance
    path('insurance_new/', insurance_list, name='insurance_list'),
    path('insurance_new/add/', add_insurance, name='add_insurance'),
    path('insurance_new/edit/<int:pk>/', edit_insurance, name='edit_insurance'),
    path('insurance_new/delete/<int:pk>/', delete_insurance, name='delete_insurance'),

    #payment
    path('payment/', views.payment_view, name='payment'),
    path('payment/success/', views.payment_success, name='payment_success'),
    #remainder
    path('reminders/', reminder_list, name='reminder_list'),
    path('reminders/add/', add_reminder, name='add_reminder'),
    path('reminders/delete/<int:reminder_id>/', delete_reminder, name='delete_reminder'),


    #claim
    path("claim-request/", claim_request_view, name="claim_request"),
    path("claim-request/", claim_request_form, name="claim_request"),

    #report
    path('report/', report_view, name='report'),
]









