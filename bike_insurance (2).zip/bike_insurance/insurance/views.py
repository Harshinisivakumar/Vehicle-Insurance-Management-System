from django.shortcuts import render, redirect, get_object_or_404
from .models import CustomUser  
from .forms import CustomerForm, PolicyForm
from .models import Policy
from django.http import FileResponse, Http404
from datetime import timedelta
from django.utils.timezone import now
import os
from django.conf import settings
from .forms import ComplaintForm
from .models import Complaint
from .models import Reminder
from .forms import ReminderForm
from .models import Customer  
from django.urls import reverse
from .forms import ClaimRequestForm
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.contrib import messages
from django.utils import timezone
from datetime import timedelta
from django.http import HttpResponse
from .forms import PaymentForm
from .models import Payment
from .models import Policy
from .forms import PolicyForm


#login

def user_login(request):
    if request.method == "POST":
        email = request.POST['email']
        password = request.POST['password']

        user = authenticate(request, username=email, password=password)
        if user is not None:
            login(request, user)
            return redirect('home')
        else:
           # messages.error(request, "Invalid email or password!")
            return redirect('login')

    return render(request, 'home.html')
def login_view(request):
    # Implement your login logic
    return render(request, 'home.html')


#signup
def signup(request):
    if request.method == "POST":
        name = request.POST['name']
        email = request.POST['email']
        phone = request.POST['phone']
        password = request.POST['password']
        confirm_password = request.POST['confirm_password']

        if password != confirm_password:
            messages.error(request, "Passwords do not match!")
            return redirect('signup')

        if CustomUser.objects.filter(email=email).exists():
            messages.error(request, "Email already registered!")
            return redirect('signup')

        user = CustomUser.objects.create_user(email=email, phone=phone, password=password)
        user.first_name = name  # Storing name in first_name field
        user.save()
        messages.success(request, "Account created successfully! Please log in.")
        return redirect('home')

    return render(request, 'signup.html')
def signup_view(request):
    # Implement your registration logic
    return render(request, 'home.html')


def customer_form_view(request):
    if request.method == "POST":
        form = CustomerForm(request.POST)
        if form.is_valid():
            customer = form.save()  # Save to the database
            return redirect(reverse("customer_success", kwargs={"customer_id": customer.id}))  # ✅ Redirect after saving
    else:
        form = CustomerForm()

    return render(request, "customer_form.html", {"form": form})


def customer_success_page(request, customer_id):
    customer = get_object_or_404(Customer, id=customer_id)  # Retrieve the saved customer
    return render(request, 'customer_success.html', {'customer': customer}) 

def edit_customer(request, customer_id):
    customer = get_object_or_404(Customer, id=customer_id)

    if request.method == "POST":
        form = CustomerForm(request.POST, instance=customer)
        if form.is_valid():
            form.save()
            return redirect('customer_list')  # Change this to your actual customer list view name
    else:
        form = CustomerForm(instance=customer)

    return render(request, 'insurance/edit_customer.html', {'form': form, 'customer': customer})



def home_view(request):
    return render(request, 'home.html')


def customer_success(request):
    return render(request, "customer_success.html")


def dealer_list(request):
    return render(request, 'dealers.html')


from django.shortcuts import render, redirect, get_object_or_404
from .models import Policy
from .forms import PolicyForm

  # Ensures only logged-in users can access this view
def policy_form_view(request, policy_id=None):
    print("-----------debug 1")

    policy = None
    if policy_id:
        print("-----------policy_id 1", policy_id)
        policy = get_object_or_404(Policy, id=policy_id)

    if request.method == "POST":
        print("-----------112", policy)
        
        policy_number = request.POST.get("policy_number")  
        print(f"Policy Number: {policy_number}")

        form = PolicyForm(request.POST, instance=policy)

        if form.is_valid():
            print("-----------113")
            policy = form.save(commit=False)

            # ✅ Fix: Check if user is authenticated before assigning customer
            if request.user.is_authenticated:
                if not policy.customer:
                    try:
                        policy.customer = request.user.customer  # Ensure the user has a related customer
                    except AttributeError:
                        return render(request, 'error.html', {'error_message': "User does not have a linked customer."})

            policy.save()
            print("-----------114")
            return redirect('policy_list')  # Ensure 'policy_list' is defined in URLs
        else:
            print("Form Errors:", form.errors)  # Will print only if form is invalid

    else:
        form = PolicyForm(instance=policy)
    
    return render(request, 'policy_form.html', {'form': form, 'policy': policy})



'''def add_policy(request):
    return add_insurance(request, 'car')  # Default to 'car' insurance'''
'''def insurance_list_view(request, insurance_type):
    return insurance_list(request)'''


def policy_list(request):
    policies = Policy.objects.all()  # Fetch all policies from the database
    return render(request, 'policy_list.html', {'policies': policies})

def edit_policy(request, policy_id):
    policy = get_object_or_404(Policy, id=policy_id)
    
    if request.method == "POST":
        form = PolicyForm(request.POST, instance=policy)
        if form.is_valid():
            form.save()
            return redirect('policy_list')  # Redirect to policy list after saving
    else:
        form = PolicyForm(instance=policy)
    
    return render(request, 'edit_policy.html', {'form': form})  # Fixed template path


def renew_policy(request, policy_id):
    policy = get_object_or_404(Policy, id=policy_id)
    
    # Extend policy start date by 1 year (example)
    policy.start_date = timezone.now()
    policy.save()

    return redirect('policy_list')


def download_policy_document(request, policy_id):
    policy = get_object_or_404(Policy, id=policy_id)

    # Generate a text response (You can replace this with a PDF generation)
    response = HttpResponse(f"Policy Document for {policy.policy_number}", content_type='text/plain')
    response['Content-Disposition'] = f'attachment; filename="policy_{policy.policy_number}.txt"'
    return response

#insurance
from .models import Insure
from .forms import InsureForm

def insurance_list(request):
    insures = Insure.objects.all()
    return render(request, 'insurance/insurance_list.html', {'insure': insures})

def add_insurance(request):
    if request.method == "POST":
        form = InsureForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            messages.success(request, "Insurance added successfully!")
            return redirect('insurance_list')  # Redirect to the insurance list page
    else:
        form = InsureForm()
    
    return render(request, "insurance/add_insurance.html", {"form": form})
def edit_insurance(request, pk):
    Insure = get_object_or_404(Insure, pk=pk)
    if request.method == "POST":
        form = InsureForm(request.POST, request.FILES, instance=Insure)
        if form.is_valid():
            form.save()
            return redirect('insurance_list')
    else:
        form = InsureForm(instance=Insure)
    return render(request, 'insurance/edit_insurance.html', {'form': form})

def delete_insurance(request, pk):
    Insure = get_object_or_404(Insure, pk=pk)
    Insure.delete()
    return redirect('insurance_list')





#complaint
from django.shortcuts import render
from django.contrib import messages
from .forms import ComplaintForm

def complaint_view(request):
    if request.method == "POST":
        form = ComplaintForm(request.POST)
        if form.is_valid():
            form.save()  # ✅ Store in the database
            messages.success(request, "Your complaint has been submitted successfully.")
            return redirect("complaint")  # ✅ Redirect to clear form
    else:
        form = ComplaintForm()

    return render(request, "complaint.html", {"form": form})

#payment
def payment_view(request):
    if request.method == 'POST':
        form = PaymentForm(request.POST)
        if form.is_valid():
            payment = form.save(commit=False)
            payment.transaction_id = 'TXN' + str(Payment.objects.count() + 1)
            payment.status = 'Completed'
            payment.save()
            return redirect('payment_success')
    else:
        form = PaymentForm()
    return render(request, 'payment.html', {'form': form})

def payment_success(request):
    return render(request, 'payment.html')

#reminder


def reminder_list(request):
    reminders = Reminder.objects.all()
    return render(request, 'reminder_list.html', {'reminders': reminders})

def add_reminder(request):
    if request.method == "POST":
        form = ReminderForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('reminder_list')
    else:
        form = ReminderForm()
    return render(request, 'add_reminder.html', {'form': form})

def delete_reminder(request, reminder_id):
    reminder = Reminder.objects.get(id=reminder_id)
    reminder.delete()
    return redirect('reminder_list')

#claim request
def claim_request_view(request):
    if request.method == "POST":
        form = ClaimRequestForm(request.POST, request.FILES)
        if form.is_valid():
            claim = form.save()
            messages.success(request, "Your Claim Request submitted successfully!")
            return redirect('claim_request')  # Redirect to prevent form resubmission
            
    else:
        form = ClaimRequestForm()
    
    return render(request, "claim_request_form.html", {"form": form})

def claim_request_form(request):
    if request.method == "POST":
        form = ClaimRequestForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect("claim_request")  # Redirect to the same page after submission
    else:
        form = ClaimRequestForm()

    return render(request, "claim_request.html", {"form": form})

#report
def report_view(request):
    customers = Customer.objects.all()
    policies = Policy.objects.all()
   # insurances = Insurance.objects.all()
    complaints = Complaint.objects.all()
    payments = Payment.objects.all()
    reminders = Reminder.objects.all()

    context = {
        'customers': customers,
        'policies': policies,
       # 'insurances': insurances,
        'complaints': complaints,
        'payments': payments,
        'reminders': reminders,
    }
    return render(request, 'report.html', context)

#logout
def user_logout(request):
    logout(request)
    return redirect('login')
