from django import forms
from django.contrib.auth.models import User  
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
from .models import Customer, Policy
from .models import Complaint
from django.contrib.auth import get_user_model
from .models import Reminder
from .models import ClaimRequest
from django.shortcuts import render, get_object_or_404, redirect
from .models import Policy 
from .models import Payment
from .models import Insure


User = get_user_model()

class CustomerForm(forms.ModelForm):
    class Meta:
        
        model = Customer
        fields = [
            'name', 'phone_number', 'email', 'address',
            'type_of_vehicle', 'vehicle_number', 'vehicle_registered_date',
            'vehicle_model', 'year_of_manufacture', 'driving_license_number'
        ]
        widgets = {
            'vehicle_registered_date': forms.DateInput(attrs={'type': 'date'}),
        }
        exclude = ['user']


'''class PolicyForm(forms.ModelForm):
    class Meta:
        model = Policy
        fields = ['policy_number', 'policy_type', 'coverage_amount', 'premium_amount', 'policy_status', 'start_date']'''

class PolicyForm(forms.ModelForm):
    class Meta:
        model = Policy
        fields = '__all__'
def policy_form_view(request, policy_id=None):
    policy = get_object_or_404(Policy, id=policy_id) if policy_id else None

    if request.method == "POST":
        form = PolicyForm(request.POST, instance=policy)
        if form.is_valid():
            form.save()
            return redirect('policy_list')
        else:
            print(form.errors)  # Debugging: Print form errors in the console

    else:
        form = PolicyForm(instance=policy)

    return render(request, 'policy_form.html', {'form': form, 'policy': policy})


class InsureForm(forms.ModelForm):
    class Meta:
        model = Insure
        fields = '__all__'
        widgets = {
            'start_date': forms.DateInput(attrs={'type': 'date'}),
            'end_date': forms.DateInput(attrs={'type': 'date'}),
        }





class ComplaintForm(forms.ModelForm):
    class Meta:
        model = Complaint
        fields = ['name', 'email', 'message',]

from django import forms
from .models import Reminder

class ReminderForm(forms.ModelForm):
    class Meta:
        model = Reminder
        fields = [
            'vehicle_number', 'policy_number', 'insurance_type', 'vehicle_type',
            'insurance_provider', 'policy_expiry_date', 'premium_due_date', 'payment_status',
            'next_payment_date', 'reminder_frequency'
        ]
        widgets = {
            'policy_expiry_date': forms.DateInput(attrs={'type': 'date'}),
            'premium_due_date': forms.DateInput(attrs={'type': 'date'}),
            'next_payment_date': forms.DateInput(attrs={'type': 'date'}),
        }
       


class ClaimRequestForm(forms.ModelForm):
    class Meta:
        model = ClaimRequest
        fields = [
            "claim_type",
            "incident_date_time",
            "incident_location",
            "description",
            "is_third_party",
            "policy_document",
            "rc_copy",
            "driving_license",
            "fir_copy",
            "accident_photos",
            "repair_estimate",
        ]
        widgets = {
            "incident_date_time": forms.DateTimeInput(attrs={"type": "datetime-local"}),
            "description": forms.Textarea(attrs={"rows": 3}),
        }

class PaymentForm(forms.ModelForm):
    class Meta:
        model = Payment
        fields = ['user', 'amount', 'payment_method']