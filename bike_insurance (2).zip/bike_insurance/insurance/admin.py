from django.contrib import admin
from .models import Policy
from .models import CustomUser, Customer, Policy,  Complaint, Insure

admin.site.register(CustomUser)
admin.site.register(Customer)
admin.site.register(Policy)
admin.site.register(Complaint)
admin.site.register(Insure)
