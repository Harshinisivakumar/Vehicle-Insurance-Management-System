from django.db import models
from django.contrib.auth.models import AbstractUser, BaseUserManager
from django.conf import settings
from django.utils.timezone import now
from django.shortcuts import render

# Custom User Manager
class CustomUserManager(BaseUserManager):
    def create_user(self, email, phone, password=None, **extra_fields):
        if not email:
            raise ValueError("The Email field must be set")
        email = self.normalize_email(email)
        extra_fields.setdefault("username", email)  # Set username to email or a default value
        
        user = self.model(email=email, phone=phone, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, phone, password=None, **extra_fields):
        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_superuser", True)
        return self.create_user(email, phone, password, **extra_fields)

# Custom User Model
class CustomUser(AbstractUser):
    phone_number = models.CharField(max_length=15, default="0000000000")

    def __str__(self):
        return self.username

# Customer Model

class Customer(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE , null=True, blank=True)
    name = models.CharField(max_length=100)
    phone_number = models.CharField(max_length=15)
    email = models.EmailField(unique=True)
    address = models.TextField()

    type_of_vehicle = models.CharField(max_length=50)
    vehicle_number = models.CharField(max_length=20, unique=True)
    vehicle_registered_date = models.DateField()
    vehicle_model = models.CharField(max_length=100, default=" ")
    year_of_manufacture = models.IntegerField(default=2000)
    driving_license_number = models.CharField(max_length=50, default=" ")

    def __str__(self):
        return f"{self.name} - {self.vehicle_number}"

# Policy Model

 
POLICY_STATUS = [
        ('Active', 'Active'),
        ('Expired', 'Expired'),
        ('Pending Renewal', 'Pending Renewal'),
    ]

VEHICLE_TYPES = [
        ('2W', 'Two-Wheeler'),
        ('4W', 'Four-Wheeler'),
        ('6W', 'Six-Wheeler'),
        ('8W', 'Eight-Wheeler'),
        ('10W', 'Ten-Wheeler'),
        ('12W', 'Twelve-Wheeler'),
        ('18W', 'Eighteen-Wheeler'),
    ]

POLICY_TYPES = [
        ('comprehensive', 'Comprehensive Insurance'),
        ('third_party', 'Third-Party Insurance'),
        ('own_damage', 'Own Damage Insurance'),
        ('zero_dep', 'Zero Depreciation Insurance'),
        ('electric', 'Electric Vehicle Insurance'),
        ('used', 'Used Vehicle Insurance'),
    ]
class Policy(models.Model):
    customer = models.ForeignKey('Customer', on_delete=models.CASCADE, null=True, blank=True)
    policy_number = models.CharField(max_length=50, unique=True)  # Keep unique if it's a reference number
    policy_type = models.CharField(max_length=20, choices=POLICY_TYPES)
    vehicle_type = models.CharField(max_length=5, choices=VEHICLE_TYPES, null=True, blank=True)  # Adjusted max_length
    coverage_amount = models.DecimalField(max_digits=10, decimal_places=2)
    premium_amount = models.DecimalField(max_digits=10, decimal_places=2)
    policy_status = models.CharField(max_length=20, choices=POLICY_STATUS)
    start_date = models.DateField()
    end_date = models.DateField(null=True, blank=True)

    def __str__(self):
        return f"{self.policy_number} - {self.policy_type}"

# Insurance Model
    
class Insure(models.Model):

    VEHICLE_TYPES = [
        ('2-wheeler', '2-Wheeler'),
        ('4-wheeler', '4-Wheeler'),
        ('6-wheeler', '6-Wheeler'),
        ('8-wheeler', '8-Wheeler'),
        ('9-wheeler', '9-Wheeler'),
    
    ]
    POLICY_STATUS = [
        ('Active', 'Active'),
        ('Expired', 'Expired'),
        ('Pending Renewal', 'Pending Renewal'),
    ]
    policy_number = models.CharField(max_length=20, unique=True)
    vehicle_type = models.CharField(max_length=20, choices=VEHICLE_TYPES, null=True, blank=True)
    insurance_type = models.CharField(max_length=50, choices=[
        ('comprehensive', 'Comprehensive'),
        ('third-party', 'Third-Party'),
        ('own-damage', 'Own Damage'),
        ('zero-depreciation', 'Zero Depreciation'),
        ('electric', 'Electric Vehicle'),
        ('used-car', 'Used Car'),
    ])
    coverage_amount = models.DecimalField(max_digits=10, decimal_places=2)
    premium_amount = models.DecimalField(max_digits=10, decimal_places=2)
    policy_status = models.CharField(max_length=20, choices=[
        ('active', 'Active'),
        ('expired', 'Expired'),
        ('pending', 'Pending'),
    ])
    start_date = models.DateField()
    end_date = models.DateField()
    document = models.FileField(upload_to='insurance_docs/', blank=True, null=True)

    def __str__(self):
        return f"{self.policy.policy_number} - {self.insurance_type}"

# Complaint Model
class Complaint(models.Model):
    name = models.CharField(max_length=100)  # ✅ This field must exist
    email = models.EmailField()  # ✅ This field must exist
    message = models.TextField()  # ✅ Ensure this field exists
    submitted_at = models.DateTimeField(auto_now_add=True)  # ✅ This ensures the field is auto-populated

    def __str__(self):
        return f"Complaint from {self.name}"  
# Reminder Model
from django.contrib.auth.models import User


class Reminder(models.Model):
    customer = models.ForeignKey('insurance.Customer', on_delete=models.CASCADE)  # Link to customer
    vehicle_number = models.CharField(max_length=20)
    policy_number = models.CharField(max_length=50)
    insurance_type = models.CharField(max_length=100)
    vehicle_type = models.CharField(max_length=50)
    insurance_provider = models.CharField(max_length=100)
    policy_expiry_date = models.DateField()
    premium_due_date = models.DateField()
    payment_status = models.CharField(max_length=10, choices=[('Paid', 'Paid'), ('Pending', 'Pending')])
    next_payment_date = models.DateField()
    reminder_frequency = models.CharField(max_length=10, choices=[('Daily', 'Daily'), ('Weekly', 'Weekly'), ('Monthly', 'Monthly')])
    reminder_via = models.CharField(max_length=10, choices=[('Email', 'Email'), ('SMS', 'SMS')])  # Ensure this line exists

    def __str__(self):
        return f"{self.vehicle_number} - {self.policy_number}"

# Claim Request Model
class ClaimRequest(models.Model):
    CLAIM_TYPES = [
        ("Accident", "Accident"),
        ("Theft", "Theft"),
        ("Third-Party Damage", "Third-Party Damage"),
        ("Fire", "Fire"),
        ("Natural Disaster", "Natural Disaster"),
        ("Other", "Other"),
    ]

    policy = models.ForeignKey(Policy, on_delete=models.CASCADE)
    claim_type = models.CharField(max_length=50, choices=CLAIM_TYPES)
    incident_date_time = models.DateTimeField()
    incident_location = models.CharField(max_length=255)
    description = models.TextField()
    is_third_party = models.BooleanField(default=False)

    # File Upload Fields
    policy_document = models.FileField(upload_to="claims/documents/", blank=True, null=True)
    rc_copy = models.FileField(upload_to="claims/rc/", blank=True, null=True)
    driving_license = models.FileField(upload_to="claims/license/", blank=True, null=True)
    fir_copy = models.FileField(upload_to="claims/fir/", blank=True, null=True)
    accident_photos = models.FileField(upload_to="claims/photos/", blank=True, null=True)
    repair_estimate = models.FileField(upload_to="claims/estimates/", blank=True, null=True)

    def __str__(self):
        return f"{self.policy.policy_number} - {self.claim_type} - {self.incident_date_time}"

# Payment Model
class Payment(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)  # Add this if needed
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    payment_method = models.CharField(max_length=100)
    created_at = models.DateTimeField(auto_now_add=True)

def report_view(request):
    customers = Customer.objects.all()
    policies = Policy.objects.all()
    insures = Insure.objects.all()
    complaints = Complaint.objects.all()
    payments = Payment.objects.all()
    reminders = Reminder.objects.all()

    context = {
        'customers': customers,
        'policies': policies,
        'insures': insures,
        'complaints': complaints,
        'payments': payments,
        'reminders': reminders,
    }
    return render(request, 'insurance/report.html', context)